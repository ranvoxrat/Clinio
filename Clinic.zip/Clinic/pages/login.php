<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="../assets/login.css">
    <link rel="stylesheet" href="../assets/fontawesome/css/fontawesome.css">
    <link rel="stylesheet" href="../assets/fontawesome/css/brands.css">
    <link rel="stylesheet" href="../assets/fontawesome/css/solid.css">
</head>
<body>
    <div class="container">
        <div class="cover">
            <div class="front">
                <img src="../assets/images/bg-login.jpg" alt="">
                <div class="text">
                    <img src="../assets/images/logo3.png" alt="">
                </div>
            </div>
        </div>
        <div class="forms">
            <div class="form-content">
                <div class="login-form">
                    <div class="title">Login <i class="fa-brands fa-codepen"></i></div>
                    <form action=" " method="POST">
                        <div class="input-boxes">
                            <div class="input-box">
                                <i class="fa-solid fa-envelope"></i>
                                <input type="text" placeholder="Enter your username" name="Username" id="Username"
                                    required autocomplete="off">
                            </div>
                            <div class="input-box">
                                <i class="fa-solid fa-lock"></i>
                                <input type="password" placeholder="Enter your password" name="Password" id="Password"
                                    required autocomplete="off">
                            </div>
                            <div class="button input-box fa-solid">
                                <input type="submit" id="login" name="login" value="Login">
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>
</html>